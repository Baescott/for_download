import os
from typing import List, Optional

from baram.ge_manager import GEManager
from great_expectations.core import ExpectationConfiguration


class GxHelper(GEManager):
    def __init__(self, run_filename):
        '''

        :param run_filename: running glue job filename
        '''

        if 'beta_public' in run_filename:
            gx_s3_bucket_name = 'sli-dst-gxbeta-public'
            data_s3_bucket_name = 'sli-dst-dlbeta-public'
        elif 'beta' in run_filename:
            gx_s3_bucket_name = 'sli-dst-gxbeta'
            data_s3_bucket_name = 'sli-dst-dlbeta'
        elif 'prod' in run_filename:
            gx_s3_bucket_name = 'sli-dst-gxprod'
            data_s3_bucket_name = 'sli-dst-dlprod'

        super().__init__(gx_s3_bucket_name, data_s3_bucket_name)

    def run(self,
            expectation_conf_list: List[ExpectationConfiguration],
            s3_file_name: Optional[str] = None,
            pandas_or_spark: str = 'pandas',
            athena_database_name: Optional[str] = None,
            athena_table_name: Optional[str] = None):
        '''
        run GX.

        :param expectation_conf_list: expectation configuration list
        :param s3_file_name: s3 file name
        :param pandas_or_spark: pandas or spark engine
        :param athena_database_name: athena database name
        :param athena_table_name: athena table name
        :return:
        '''
        suite_name = os.path.basename(__file__).replace('.py', '')
        super().run(suite_name,
                    expectation_conf_list,
                    s3_file_name,
                    pandas_or_spark,
                    athena_database_name,
                    athena_table_name)
