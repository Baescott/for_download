import os
import re

from pyspark import SparkContext
from pyspark.sql.dataframe import DataFrame

from awsglue import DynamicFrame
from awsglue.context import GlueContext


class GlueHelper(object):
    def __init__(self, from_s3_bucket_name: str, to_s3_bucket_name: str = None):
        '''

        :param from_s3_bucket_name: source s3 bucket name ex) sli-dst-dlbeta
        :param to_s3_bucket_name: target s3 bucket name ex) sli-dst-dlbeta
        '''
        self.from_s3_bucket_name = from_s3_bucket_name
        self.to_s3_bucket_name = to_s3_bucket_name if to_s3_bucket_name else from_s3_bucket_name
        self.sc = SparkContext('local', 'test') if 'PHASE' in os.environ and os.environ[
            'PHASE'] == 'BETA' else SparkContext()
        self.glueContext = GlueContext(self.sc)
        self.spark = self.glueContext.spark_session
        self.pattern = re.compile(r'(?<!^)(?=[A-Z])')

    def from_csv_to_dataframe(self,
                              from_s3_path: str,
                              csv_header: bool = True,
                              csv_seperator: str = ',',
                              recursiveFileLookup: bool = False) -> DataFrame:
        '''
        Load s3 csv file(s) to spark dataframe.

        :param from_s3_path: s3 path. ex) incoming/titanic.csv means s3://bucket_name/incoming/titanic.csv
        :param csv_header: include csv header or not
        :param csv_seperator: csv seperator, default is ','
        :param recursiveFileLookup: True if s3 path is directory
        :return:
        '''
        df = self.spark.read \
            .options(**{'header': csv_header,
                        'sep': csv_seperator,
                        'recursiveFileLookup': recursiveFileLookup,
                        'encoding': 'euc-kr'}) \
            .csv(os.path.join('s3://', self.from_s3_bucket_name, from_s3_path))
        df.printSchema()
        return df

    def from_dataframe_to_glue_catalog(self,
                                       df: DataFrame,
                                       to_db_name: str,
                                       to_table_name: str,
                                       mappings: list,
                                       partition_keys: list = []):
        '''
        Create or update glue catalog from spark dataframe.

        :param df: dataframe object
        :param to_db_name: target glue database name
        :param to_table_name: target glue table name
        :param mappings: csv to glue catalog mappings
        :param partition_keys: partition key if you want
        :return:
        '''

        table_path = self._get_table_path(self.to_s3_bucket_name) \
            if self.to_s3_bucket_name else self._get_table_path(self.from_s3_bucket_name)
        output_path = f'{table_path}/{to_db_name}/{to_table_name}'

        dynamic_f = DynamicFrame.fromDF(df, self.glueContext, 'dynamic_f')

        mapping_len = len(mappings[0]) if len(mappings) > 0 else 0
        new_mappings = []
        if mapping_len == 3:
            for m in mappings:
                m = list(m)
                m.insert(1, 'string')
                new_mappings.append(tuple(m))
            mappings = new_mappings
        elif mapping_len == 2:
            for m in mappings:
                m = list(m)
                m.insert(1, 'string')
                m.insert(2, self.pattern.sub('_', m[0]).lower())
                new_mappings.append(tuple(m))
            mappings = new_mappings

        dynamic_f = dynamic_f.apply_mapping(mappings)
        dynamic_f.printSchema()

        options = {'path': output_path,
                   'enableUpdateCatalog': 'true',
                   'updateBehavior': 'UPDATE_IN_DATABASE'}
        if len(partition_keys) > 0:
            options['partitionKeys'] = partition_keys

        sink = self.glueContext.getSink('s3', **options)
        sink.setFormat('glueparquet')
        sink.setCatalogInfo(to_db_name, to_table_name)
        sink.writeFrame(dynamic_f)

    def _get_table_path(self, s3_bucket_name: str):
        '''

        :param s3_bucket_name: s3 bucket name
        :return:
        '''
        return os.path.join('s3://', s3_bucket_name, 'table')
